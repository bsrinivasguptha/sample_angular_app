import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared/shared.service'

@Component({
  selector: 'app-analyze',
  templateUrl: './analyze.component.html',
  styleUrls: ['./analyze.component.scss']
})
export class AnalyzeComponent implements OnInit {

  message: string;

  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sharedService.currentMessage.subscribe( message => {this.message = message} )
  }

}
