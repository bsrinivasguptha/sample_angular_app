import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared/shared.service';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  expanded = true;

    constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    // setTimeout(() => {
    //   this.toggleView();
    // }, 2000);
  }

  toggleView(){
    this.expanded = !this.expanded;
  }


  updateMessage(){
    this.sharedService.changeMessage("This message is updated from SideNav component")
  }

}
