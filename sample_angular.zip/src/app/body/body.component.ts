import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared/shared.service'

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.scss']
})
export class BodyComponent implements OnInit {

  message: string;

  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sharedService.currentMessage.subscribe(message => { this.message = message })
  }

  updateMessage(message: string){
    this.sharedService.changeMessage(message);
  }

}
